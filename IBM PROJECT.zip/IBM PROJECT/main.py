#needed library
import cv2
import face_recognition
import numpy as np
import pandas as pd
from datetime import datetime

# load student images and create encodings
def load_student_images(image_paths, student_names):
    encodings = []
    for img_path in image_paths:
        image = face_recognition.load_image_file(img_path)
        encoding = face_recognition.face_encodings(image)[0]
        encodings.append(encoding)
    return encodings, student_names

def mark_attendance(name):
    with open('attendance.csv', 'r+') as file:
        data = file.readlines()
        name_list = [line.split(',')[0] for line in data]
        if name not in name_list:
            now = datetime.now()
            time_str = now.strftime('%H:%M:%S')
            date_str = now.strftime('%Y-%m-%d')
            file.writelines(f'{name},{date_str},{time_str}\n')

# student name and image
image_paths = ['nihalk.jpg', 'rithvik.jpg', 'rahul.jpg', 'prajwal.jpg', 'sanjay.jpg']  
student_names = ['Nihal Karkera', 'Rithvik', 'Rahul Mahale', 'Prajwal Musali', 'Sanjay Moolya'] 

known_encodings, known_names = load_student_images(image_paths, student_names)

# webcam
video_capture = cv2.VideoCapture(0)

while True:
    # capture frame from webcam
    ret, frame = video_capture.read()
    
    # resize frame for faster processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    rgb_small_frame = small_frame[:, :, ::-1]  # Convert to RGB
    
    # find faces and encodings in the current frame
    face_locations = face_recognition.face_locations(rgb_small_frame)
    face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
    
    # loop through each detected face
    for face_encoding, face_location in zip(face_encodings, face_locations):
        matches = face_recognition.compare_faces(known_encodings, face_encoding)
        name = "Unknown"
        
        # use the known face with the smallest distance
        face_distances = face_recognition.face_distance(known_encodings, face_encoding)
        best_match_index = np.argmin(face_distances)
        if matches[best_match_index]:
            name = known_names[best_match_index]
        
        # mark attendance
        mark_attendance(name)
        
        # show the name of the person on the video feed
        top, right, bottom, left = [v * 4 for v in face_location]
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2)

    # display video frame with bounding boxes and names
    cv2.imshow('Video', frame)
    
    # exit with 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# release resources
video_capture.release()
cv2.destroyAllWindows()
